history_samples_video_example_100fish_1min.npz
----------------------------------------------
Only val_loss and val_acc from this file are used.
It contains all accuracy and loss values for all trials using different normalization methods:

	- posture (e.g. TRex)
	- moments (e.g. idtracker.ai)
	- none

F5_source_data_convergence.csv
------------------------------
Pre-processed data, as plotted in figure 5.

For more information, please see -- and when using any data in your work, cite:
Walter, Tristan et al. (2020). Reproduction Data for: TRex, a fast multi-animal tracking system with markerless identification, and 2D estimation of posture and visual fields. Max Planck Society. https://dx.doi.org/10.17617/3.4y